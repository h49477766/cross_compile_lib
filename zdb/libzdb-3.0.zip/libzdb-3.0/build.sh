source ~/set_environment-kanontec.sh
./configure --host=arm-none-linux-gnueabi --prefix=/home/huanghm/work/kanontec_lib/zdb/install
